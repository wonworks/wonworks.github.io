2030 HEY GANGNAM 팀 웹사이트

- index.html : 더블클릭으로 바로 열리는 사이트 (모든 이미지 내장, 인터넷 없이 작동)
- assets/    : 사이트에 쓰인 이미지 원본
    00_logo      로고
    01_intro     히어로 인트로 이미지
    02_world     월드 조감도
    03_system    시스템 이미지
    04_route     관람 동선 4지점 이미지
    05_products  제품 이미지 (배지 · TIME DIAL · Echo Ring · 펜스)
