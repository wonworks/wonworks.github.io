글꼴: Pretendard Variable

index.html 이 인터넷 연결 시 jsDelivr CDN에서 불러옵니다.
(https://cdn.jsdelivr.net/gh/orioncactus/pretendard)
인터넷이 없으면 시스템 글꼴(Apple SD Gothic Neo, 맑은 고딕)로 표시됩니다.

오프라인에서도 같은 글꼴을 쓰려면 PretendardVariable.woff2 를 이 폴더에 넣고
css/style.css 맨 위에 다음을 추가하세요.

@font-face{font-family:"Pretendard Variable";src:url("../fonts/PretendardVariable.woff2") format("woff2-variations");font-weight:45 920;font-display:swap}
